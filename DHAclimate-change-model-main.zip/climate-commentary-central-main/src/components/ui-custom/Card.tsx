
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glassEffect?: boolean;
  neoEffect?: boolean;
}

const Card = ({ 
  children, 
  className, 
  hover = false,
  glassEffect = false,
  neoEffect = false
}: CardProps) => {
  return (
    <div 
      className={cn(
        "rounded-xl overflow-hidden transition-all duration-300 ease-in-out",
        hover && "hover:translate-y-[-4px] hover:shadow-glass-lg",
        glassEffect && "glass-panel",
        neoEffect && "neo-panel",
        !glassEffect && !neoEffect && "bg-card border border-border shadow-sm",
        className
      )}
    >
      {children}
    </div>
  );
};

export default Card;
