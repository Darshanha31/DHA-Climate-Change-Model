
import { cn } from "@/lib/utils";
import Card from "./Card";

interface CommentCardProps {
  text: string;
  profileName: string;
  date: string;
  likesCount: number;
  commentsCount: number;
  sentiment?: "positive" | "negative" | "neutral";
  className?: string;
}

const CommentCard = ({
  text,
  profileName,
  date,
  likesCount,
  commentsCount,
  sentiment = "neutral",
  className
}: CommentCardProps) => {
  // Determine sentiment color
  const sentimentColor = 
    sentiment === "positive" ? "bg-green-100 text-green-800" :
    sentiment === "negative" ? "bg-red-100 text-red-800" :
    "bg-blue-100 text-blue-800";
  
  return (
    <Card className={cn("animate-scale-in", className)} glassEffect>
      <div className="p-5 space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex space-x-3 items-center">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium">
              {profileName.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-medium text-sm">{profileName}</p>
              <p className="text-xs text-muted-foreground">{date}</p>
            </div>
          </div>
          <div className={cn("text-xs py-1 px-3 rounded-full font-medium", sentimentColor)}>
            {sentiment.charAt(0).toUpperCase() + sentiment.slice(1)}
          </div>
        </div>
        
        <p className="text-sm text-foreground/90 leading-relaxed">{text}</p>
        
        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" 
              />
            </svg>
            <span>{likesCount} likes</span>
          </div>
          <div className="flex items-center space-x-1">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" 
              />
            </svg>
            <span>{commentsCount} replies</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CommentCard;
