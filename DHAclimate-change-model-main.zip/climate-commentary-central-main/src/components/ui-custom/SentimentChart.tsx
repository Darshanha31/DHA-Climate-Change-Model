
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import Card from './Card';

interface SentimentChartProps {
  data: {
    positive: number;
    negative: number;
    neutral: number;
  };
  className?: string;
}

const SentimentChart = ({ data, className }: SentimentChartProps) => {
  const chartData = [
    { name: 'Positive', value: data.positive, color: '#10b981' },
    { name: 'Negative', value: data.negative, color: '#ef4444' },
    { name: 'Neutral', value: data.neutral, color: '#3b82f6' },
  ];
  
  return (
    <Card className={className} glassEffect>
      <div className="p-5">
        <h3 className="text-lg font-semibold mb-4">Sentiment Distribution</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                fill="#8884d8"
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </Card>
  );
};

export default SentimentChart;
