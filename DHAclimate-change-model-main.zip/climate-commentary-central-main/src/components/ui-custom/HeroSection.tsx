
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  const navigate = useNavigate();
  const [loaded, setLoaded] = useState(false);
  
  useEffect(() => {
    setLoaded(true);
  }, []);
  
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background to-secondary/30 z-0"></div>
      
      {/* Content */}
      <div className="container mx-auto px-6 md:px-10 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div 
            className={`transition-all duration-700 delay-100 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-8"
            }`}
          >
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-xs font-semibold tracking-wide mb-4">
              Analyzing Climate Data
            </span>
          </div>
          
          <h1 
            className={`text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-tight md:leading-tight lg:leading-tight text-balance transition-all duration-700 delay-200 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-8"
            }`}
          >
            Modeling and Understanding <span className="text-gradient">Climate Change</span>
          </h1>
          
          <p 
            className={`text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-balance transition-all duration-700 delay-300 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-8"
            }`}
          >
            Explore over 500 comments from NASA's climate change Facebook page, analyzed for sentiment and engagement to better understand public opinion.
          </p>
          
          <div 
            className={`flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 transition-all duration-700 delay-400 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-8"
            }`}
          >
            <Button 
              size="lg" 
              onClick={() => navigate('/dashboard')}
              className="rounded-full px-8 shadow-glass-sm bg-primary hover:bg-primary/90 transition-all"
            >
              Explore Dashboard
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="rounded-full px-8 border-2 bg-transparent hover:bg-secondary/50 transition-all"
            >
              Learn More
            </Button>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div 
        className={`absolute bottom-16 left-1/2 transform -translate-x-1/2 w-24 h-24 rounded-full bg-primary/5 transition-all duration-1000 ${
          loaded ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="w-full h-full animate-float">
          <div className="w-full h-full rounded-full bg-primary/10 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
