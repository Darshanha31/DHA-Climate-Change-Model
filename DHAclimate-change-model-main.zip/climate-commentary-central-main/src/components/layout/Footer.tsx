
import { cn } from "@/lib/utils";

const Footer = () => {
  return (
    <footer className="w-full py-12 px-6 md:px-10 bg-secondary/50">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Climate Change Modeling</h3>
            <p className="text-sm text-muted-foreground">
              Analyzing public sentiment about climate change through NASA's social media engagement.
            </p>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a 
                  href="https://climate.nasa.gov/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  NASA Climate
                </a>
              </li>
              <li>
                <a 
                  href="https://www.ipcc.ch/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  IPCC
                </a>
              </li>
              <li>
                <a 
                  href="https://www.noaa.gov/climate" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  NOAA Climate
                </a>
              </li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">About This Project</h3>
            <p className="text-sm text-muted-foreground">
              This project analyzes over 500 user comments from NASA's Facebook page on climate change, offering insights through sentiment analysis and data visualization.
            </p>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-border">
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Climate Change Modeling. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
