
import { useEffect } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/ui-custom/HeroSection";
import FeaturesSection from "@/components/ui-custom/FeaturesSection";
import Card from "@/components/ui-custom/Card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();
  
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow pt-16">
        <HeroSection />
        <FeaturesSection />
        
        {/* Data Overview Section */}
        <section className="py-20 px-6 md:px-10 bg-secondary/30">
          <div className="container mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-xs font-semibold tracking-wide mb-4">
                Data Overview
              </span>
              <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">
                What's In Our Dataset
              </h2>
              <p className="text-muted-foreground text-balance">
                We've collected and analyzed comments from NASA's climate change Facebook page
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="p-8 text-center" glassEffect>
                <div className="text-4xl font-bold text-primary mb-2">500+</div>
                <p className="text-muted-foreground">User Comments</p>
              </Card>
              
              <Card className="p-8 text-center" glassEffect>
                <div className="text-4xl font-bold text-primary mb-2">2020-2023</div>
                <p className="text-muted-foreground">Date Range</p>
              </Card>
              
              <Card className="p-8 text-center" glassEffect>
                <div className="text-4xl font-bold text-primary mb-2">5</div>
                <p className="text-muted-foreground">Data Dimensions</p>
              </Card>
            </div>
            
            <div className="mt-16 text-center">
              <Button 
                size="lg" 
                onClick={() => navigate('/dashboard')}
                className="rounded-full px-8 shadow-glass-sm bg-primary hover:bg-primary/90 transition-all"
              >
                Explore the Dashboard
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
