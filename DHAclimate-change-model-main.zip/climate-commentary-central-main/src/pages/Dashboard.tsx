
import { useEffect, useState } from "react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Card from "@/components/ui-custom/Card";
import SentimentChart from "@/components/ui-custom/SentimentChart";
import CommentCard from "@/components/ui-custom/CommentCard";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// Sample data
const sampleComments = [
  {
    id: 1,
    text: "Climate change is real and we need to take action now. Thank you NASA for your research and making this data accessible to everyone.",
    profileName: "ClimateAdvocate",
    date: "March 15, 2023",
    likesCount: 245,
    commentsCount: 32,
    sentiment: "positive"
  },
  {
    id: 2,
    text: "I'm not convinced by these graphs. The data seems cherry-picked to push an agenda. Where's the raw data?",
    profileName: "SkepticalThinker",
    date: "January 22, 2023",
    likesCount: 78,
    commentsCount: 124,
    sentiment: "negative"
  },
  {
    id: 3,
    text: "Interesting visualization of the temperature trends. Would be helpful to see this compared to historical cycles over longer periods.",
    profileName: "DataAnalyst",
    date: "November 5, 2022",
    likesCount: 132,
    commentsCount: 14,
    sentiment: "neutral"
  },
  {
    id: 4,
    text: "The recent IPCC report confirms what NASA has been saying for years. The evidence is overwhelming and we need policy changes now.",
    profileName: "ScienceSupporter",
    date: "October 10, 2022",
    likesCount: 310,
    commentsCount: 45,
    sentiment: "positive"
  },
  {
    id: 5,
    text: "These satellite images showing glacier retreat are striking. It's hard to argue with visual evidence like this.",
    profileName: "GeoObserver",
    date: "August 3, 2022",
    likesCount: 189,
    commentsCount: 21,
    sentiment: "positive"
  },
  {
    id: 6,
    text: "Why are we wasting tax dollars on this when there are more immediate problems to solve? This seems like a distraction.",
    profileName: "PragmaticCitizen",
    date: "July 17, 2022",
    likesCount: 43,
    commentsCount: 67,
    sentiment: "negative"
  }
];

const engagementData = [
  { month: 'Jan', likes: 1250, comments: 350 },
  { month: 'Feb', likes: 1500, comments: 420 },
  { month: 'Mar', likes: 1800, comments: 590 },
  { month: 'Apr', likes: 2100, comments: 670 },
  { month: 'May', likes: 1700, comments: 480 },
  { month: 'Jun', likes: 1900, comments: 520 },
];

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredComments, setFilteredComments] = useState(sampleComments);
  const [loaded, setLoaded] = useState(false);
  
  // Scroll to top on page load
  useEffect(() => {
    window.scrollTo(0, 0);
    setLoaded(true);
  }, []);
  
  // Filter comments based on search term
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredComments(sampleComments);
    } else {
      const filtered = sampleComments.filter(comment => 
        comment.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comment.profileName.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredComments(filtered);
    }
  }, [searchTerm]);
  
  // Count sentiment distribution
  const sentimentData = {
    positive: sampleComments.filter(comment => comment.sentiment === "positive").length,
    negative: sampleComments.filter(comment => comment.sentiment === "negative").length,
    neutral: sampleComments.filter(comment => comment.sentiment === "neutral").length,
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow pt-24 pb-16 px-6 md:px-10">
        <div className="container mx-auto">
          <div 
            className={`transition-all duration-700 delay-200 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-4"
            }`}
          >
            <h1 className="text-3xl md:text-4xl font-bold font-display mb-2">Climate Change Modeling Dashboard</h1>
            <p className="text-muted-foreground mb-8">Analyze sentiment and engagement trends in climate change discussions</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div 
              className={`md:col-span-2 transition-all duration-700 delay-300 ${
                loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-4"
              }`}
            >
              <Card className="h-full" glassEffect>
                <div className="p-5">
                  <h3 className="text-lg font-semibold mb-4">Engagement Over Time</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={engagementData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip
                          contentStyle={{
                            background: "rgba(255, 255, 255, 0.8)",
                            border: "none",
                            borderRadius: "8px",
                            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)"
                          }}
                        />
                        <Bar dataKey="likes" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Likes" />
                        <Bar dataKey="comments" fill="#8b5cf6" radius={[4, 4, 0, 0]} name="Comments" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </Card>
            </div>
            
            <div 
              className={`transition-all duration-700 delay-400 ${
                loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-4"
              }`}
            >
              <SentimentChart data={sentimentData} className="h-full" />
            </div>
          </div>
          
          <div 
            className={`mb-8 transition-all duration-700 delay-500 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-4"
            }`}
          >
            <Card className="p-5" glassEffect>
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <h3 className="text-lg font-semibold">Comment Analysis</h3>
                <div className="w-full md:w-64">
                  <Input
                    placeholder="Search comments..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>
            </Card>
          </div>
          
          <div 
            className={`transition-all duration-700 delay-600 ${
              loaded ? "opacity-100 transform-none" : "opacity-0 translate-y-4"
            }`}
          >
            <Tabs defaultValue="all">
              <TabsList className="mb-6">
                <TabsTrigger value="all">All Comments</TabsTrigger>
                <TabsTrigger value="positive">Positive</TabsTrigger>
                <TabsTrigger value="negative">Negative</TabsTrigger>
                <TabsTrigger value="neutral">Neutral</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredComments.map((comment, index) => (
                    <CommentCard
                      key={comment.id}
                      text={comment.text}
                      profileName={comment.profileName}
                      date={comment.date}
                      likesCount={comment.likesCount}
                      commentsCount={comment.commentsCount}
                      sentiment={comment.sentiment as any}
                      className="transition-all"
                    />
                  ))}
                  
                  {filteredComments.length === 0 && (
                    <div className="col-span-full text-center py-10">
                      <p className="text-muted-foreground">No comments match your search criteria.</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="positive">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredComments
                    .filter(comment => comment.sentiment === "positive")
                    .map((comment) => (
                      <CommentCard
                        key={comment.id}
                        text={comment.text}
                        profileName={comment.profileName}
                        date={comment.date}
                        likesCount={comment.likesCount}
                        commentsCount={comment.commentsCount}
                        sentiment="positive"
                        className="transition-all"
                      />
                    ))}
                    
                    {filteredComments.filter(comment => comment.sentiment === "positive").length === 0 && (
                      <div className="col-span-full text-center py-10">
                        <p className="text-muted-foreground">No positive comments match your search criteria.</p>
                      </div>
                    )}
                </div>
              </TabsContent>
              
              <TabsContent value="negative">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredComments
                    .filter(comment => comment.sentiment === "negative")
                    .map((comment) => (
                      <CommentCard
                        key={comment.id}
                        text={comment.text}
                        profileName={comment.profileName}
                        date={comment.date}
                        likesCount={comment.likesCount}
                        commentsCount={comment.commentsCount}
                        sentiment="negative"
                        className="transition-all"
                      />
                    ))}
                    
                    {filteredComments.filter(comment => comment.sentiment === "negative").length === 0 && (
                      <div className="col-span-full text-center py-10">
                        <p className="text-muted-foreground">No negative comments match your search criteria.</p>
                      </div>
                    )}
                </div>
              </TabsContent>
              
              <TabsContent value="neutral">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {filteredComments
                    .filter(comment => comment.sentiment === "neutral")
                    .map((comment) => (
                      <CommentCard
                        key={comment.id}
                        text={comment.text}
                        profileName={comment.profileName}
                        date={comment.date}
                        likesCount={comment.likesCount}
                        commentsCount={comment.commentsCount}
                        sentiment="neutral"
                        className="transition-all"
                      />
                    ))}
                    
                    {filteredComments.filter(comment => comment.sentiment === "neutral").length === 0 && (
                      <div className="col-span-full text-center py-10">
                        <p className="text-muted-foreground">No neutral comments match your search criteria.</p>
                      </div>
                    )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
